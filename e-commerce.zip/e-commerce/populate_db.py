import sqlite3
from datetime import datetime, timedelta

# Connexion à la base de données
conn = sqlite3.connect('ecommerce.db')
cursor = conn.cursor()

# Création de la table avec la colonne is_auction
cursor.execute('''
    CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        stock INTEGER NOT NULL CHECK(stock >= 0),
        image TEXT DEFAULT 'placeholder.jpg',
        is_auction INTEGER DEFAULT 0
    )
''')
print("✅ Table 'products' créée ou existante.")

cursor.execute('''
    CREATE TABLE IF NOT EXISTS auction (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER,
        start_time TEXT,
        end_time TEXT,
        is_active INTEGER DEFAULT 1,
        FOREIGN KEY(product_id) REFERENCES products(id)
    )
''')
print("✅ Table 'auction' créée ou existante.")

# Vérifie si la colonne 'is_auction' est bien là (sécurité)
cursor.execute("PRAGMA table_info(products)")
columns = [col[1] for col in cursor.fetchall()]
if 'is_auction' not in columns:
    cursor.execute("ALTER TABLE products ADD COLUMN is_auction INTEGER DEFAULT 0")
    print("✅ Colonne 'is_auction' ajoutée manuellement.")

# Vérifie s’il y a déjà des produits
cursor.execute("SELECT COUNT(*) FROM products")
count = cursor.fetchone()[0]

if count == 0:
    products = [
        ("Laptop", 799.99, 10, "laptop.jpg", 0),
        ("Smartphone", 499.99, 15, "Teljpg.jpg", 0),
        ("Casque Bluetooth", 59.99, 20, "Casque.jpg", 0),
        ("Souris Gamer", 29.99, 30, "souris.jpg", 0),
        ("Clavier Mécanique", 89.99, 25, "clavier.jpg", 0),
        ("Bag Dior", 3999.99, 1, "Dior.jpg", 1),
        ("Bag Chanel", 2999, 1, "Chanel.jpg", 1),
        ("Bag Gucci", 2000, 1, "Gucci.jpg", 1),
        ("Bag Louis Vuitton", 1499.99, 1, "Louis_Vuitton.jpg", 1)
    ]

    cursor.executemany(
        "INSERT INTO products (name, price, stock, image, is_auction) VALUES (?, ?, ?, ?, ?)",
        products
    )
    conn.commit()
    print("✅ Produits ajoutés à la base de données.")

    # Création des enchères pour les sacs
    cursor.execute("SELECT id FROM products WHERE is_auction = 1")
    auction_products = cursor.fetchall()
    now = datetime.utcnow()

    auctions = [
        (product_id[0], now.isoformat(), (now + timedelta(minutes=30)).isoformat(), 1)
        for product_id in auction_products
    ]

    cursor.executemany(
        "INSERT INTO auction (product_id, start_time, end_time, is_active) VALUES (?, ?, ?, ?)",
        auctions
    )
    conn.commit()
    print("✅ Enchères créées pour les sacs de luxe.")

else:
    print("ℹ️ Produits déjà présents, aucun ajout nécessaire.")

conn.close()
print("✅ Base de données prête !")