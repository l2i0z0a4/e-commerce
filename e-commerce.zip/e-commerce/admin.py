from flask import Blueprint, render_template, request, redirect, url_for
from models import db, Product

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/admin')
def admin_dashboard():
    products = Product.query.all()
    return render_template('admin.html', products=products)

@admin_bp.route('/add_stock/<int:product_id>', methods=['POST'])
def add_stock(product_id):
    product = Product.query.get(product_id)
    if product:
        product.stock += int(request.form['quantity'])
        db.session.commit()
    return redirect(url_for('admin.admin_dashboard'))
