from flask import Flask, render_template, request, redirect, url_for, jsonify, session, send_file
from flask_sqlalchemy import SQLAlchemy
import stripe
from generate_invoice import generate_invoice
from flask_mail import Mail, Message
import os
from datetime import datetime, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from pusher_config_example import pusher_client
from flask_cors import CORS
import joblib
import pandas as pd
import numpy as np
from flask import jsonify


# Charger le modèle sauvegardé
model = joblib.load('model_pipeline.pkl')


app = Flask(__name__)

# Configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///ecommerce.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'secret'
app.config['UPLOAD_FOLDER'] = os.path.join('static', 'images')
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}

# Stripe
stripe.api_key = "sk_test_51QvzwnKSOPBHXeDw42sm4oSPse5qFD7nGcL4xf8VfshNGzj5R4Sluqc52H4JQSOBBGVhVlmk9Uyd5uAVLKTjCS6e00jr9FVFFv"
STRIPE_PUBLIC_KEY = "pk_test_51QvzwnKSOPBHXeDwplHTdeSwlDRgi1B3ZwpZAY638AuTJaWDL7R9WYQRmat6KNLWaCHvrECsVSVlwOZWXkzhpDku0093aRotO1"

# Mail
app.config['MAIL_SERVER'] = 'smtp.office365.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'lizamezioug03@outlook.com'
app.config['MAIL_PASSWORD'] = 'Liza792003'
mail = Mail(app)

# DB
db = SQLAlchemy(app)

# Models
class Product(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    brand = db.Column(db.String(100))
    bag_style = db.Column(db.String(100))
    skin_type = db.Column(db.String(100))
    inner_material = db.Column(db.String(100))
    major_color = db.Column(db.String(100))
    volume = db.Column(db.Float)
    accessories = db.Column(db.String(200))
    price = db.Column(db.Float)
    stock = db.Column(db.Integer)
    image = db.Column(db.String(200))
    is_auction = db.Column(db.Boolean, default=False)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True)
    password = db.Column(db.String(200))
    is_admin = db.Column(db.Boolean, default=False)

class Auction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    start_time = db.Column(db.DateTime)
    end_time = db.Column(db.DateTime)
    is_active = db.Column(db.Boolean, default=True)
    product = db.relationship('Product')

class Bid(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_email = db.Column(db.String(120))
    auction_id = db.Column(db.Integer, db.ForeignKey('auction.id'))
    amount = db.Column(db.Float)
    bid_time = db.Column(db.DateTime, default=datetime.utcnow)
    auction = db.relationship('Auction')

# Helper function for file uploads
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Init DB + insert data
with app.app_context():
    db.create_all()
    
    # Create admin user if doesn't exist
    admin_user = User.query.filter_by(email='admin@admin.com').first()
    if not admin_user:
        hashed_password = generate_password_hash('adm1243')
        admin_user = User(email='admin@admin.com', password=hashed_password, is_admin=True)
        db.session.add(admin_user)
        db.session.commit()

    if not Product.query.first():
        sample_products = [

            Product(name="Bag Dior", price=3999.99, image="Dior.jpg", stock=1, is_auction=True),
            Product(name="Bag Chanel", price=2999.99, image="Chanel.jpg", stock=1, is_auction=True),
            Product(name="Bag Gucci", price=2000.00, image="Gucci.jpg", stock=1, is_auction=True),
            Product(name="Bag Louis Vuitton", price=1499.99, image="Louis_Vuitton.jpg", stock=1, is_auction=True)
        ]
        db.session.add_all(sample_products)
        db.session.commit()

    if not Auction.query.first():
        now = datetime.utcnow()
        auction_products = Product.query.filter_by(is_auction=True).all()
        for product in auction_products:
            auction = Auction(
                product_id=product.id,
                start_time=now,
                end_time=now + timedelta(hours=2),
                is_active=True
            )
            db.session.add(auction)
        db.session.commit()

# Routes
@app.route('/')
def index():
    products = Product.query.all()
    cart_items = session.get('cart', {})
    cart_count = sum(cart_items.values())
    return render_template('index.html', products=products, cart_count=cart_count, stripe_public_key=STRIPE_PUBLIC_KEY)

# Authentication routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        redirect_to = request.args.get('redirect', 'index')

        if not email or not password:
            return "Champs manquants", 400

        user = User.query.filter_by(email=email).first()
        
        if user:
            if check_password_hash(user.password, password):
                session['customer_email'] = email
                
                if user.is_admin:
                    return redirect(url_for('admin'))
                
                if redirect_to == 'checkout':
                    return redirect(url_for('create_checkout_session'))
                return redirect(url_for('index'))
            else:
                return redirect(url_for('login', error='login'))
        else:
            try:
                hashed_password = generate_password_hash(password)
                new_user = User(email=email, password=hashed_password)
                db.session.add(new_user)
                db.session.commit()
                session['customer_email'] = email
                
                if redirect_to == 'checkout':
                    return redirect(url_for('create_checkout_session'))
                return redirect(url_for('index'))
            except Exception as e:
                return redirect(url_for('login', error='register'))

    return render_template('login.html')

@app.route('/check-auth')
def check_auth():
    if 'customer_email' in session:
        return jsonify({'authenticated': True}), 200
    else:
        return jsonify({'authenticated': False}), 401

# Cart routes
@app.route('/cart')
def cart():
    cart_items = session.get('cart', {})
    cart_data = []
    total_price = 0

    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            total_price += product.price * quantity
            cart_data.append({'product': product, 'quantity': quantity})

    return render_template('cart.html', cart_items=cart_data, total_price=total_price)

@app.route('/add_to_cart/<int:product_id>', methods=['POST'])
def add_to_cart(product_id):
    product = Product.query.get(product_id)
    if not product or product.stock <= 0:
        return jsonify({'error': 'Stock insuffisant'}), 400

    cart = session.get('cart', {})

    if cart.get(str(product_id), 0) >= product.stock:
        return jsonify({'error': 'Stock insuffisant'}), 400

    cart[str(product_id)] = cart.get(str(product_id), 0) + 1
    session['cart'] = cart
    session.modified = True

    return jsonify({'cart_count': sum(cart.values())})

@app.route('/decrease_cart/<int:product_id>', methods=['POST'])
def decrease_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        session['cart'][str(product_id)] -= 1

        if session['cart'][str(product_id)] <= 0:
            del session['cart'][str(product_id)]

        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session.get('cart') else 0})

@app.route('/remove_from_cart/<int:product_id>', methods=['POST'])
def remove_from_cart(product_id):
    if 'cart' in session and str(product_id) in session['cart']:
        del session['cart'][str(product_id)]
        session.modified = True

    return jsonify({'cart_count': sum(session['cart'].values()) if session.get('cart') else 0})

@app.route('/clear_cart')
def clear_cart():
    session.pop('cart', None)
    return redirect(url_for('cart'))

# Stripe checkout
@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    if 'customer_email' not in session:
        print("❌ Utilisateur non connecté — redirection vers login")
        return redirect(url_for('login', redirect='checkout'))

    cart_items = session.get('cart', {})
    if not cart_items:
        return redirect(url_for('cart'))
        
    line_items = []
    
    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            line_items.append({
                'price_data': {
                    'currency': 'eur',
                    'product_data': {'name': product.name},
                    'unit_amount': int(product.price * 100),
                },
                'quantity': quantity
            })
    
    try:
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=url_for('success', _external=True),
            cancel_url=url_for('cart', _external=True),
            customer_email=session.get('customer_email')
        )
        return redirect(checkout_session.url, code=303)
    except Exception as e:
        print(f"Erreur Stripe: {e}")
        return redirect(url_for('cart'))

@app.route('/success')
def success():
    cart_items = session.get('cart', {})

    if not cart_items:
        return redirect(url_for('index'))

    customer_name = session.get('customer_name', 'Client inconnu')
    customer_email = session.get('customer_email', '')
    order_id = f"CMD{int(datetime.now().timestamp())}"

    items = []
    total_price = 0
    for product_id, quantity in cart_items.items():
        product = Product.query.get(product_id)
        if product:
            items.append({
                'name': product.name,
                'quantity': quantity,
                'price': product.price
            })
            total_price += product.price * quantity
            product.stock -= quantity

    db.session.commit()

    invoice_path = generate_invoice(order_id, customer_name, customer_email, items, total_price)

    if customer_email:
        try:
            msg = Message("Votre Facture", sender=app.config['MAIL_USERNAME'], recipients=[customer_email])
            msg.body = "Veuillez trouver votre facture ci-jointe."
            with app.open_resource(invoice_path) as fp:
                msg.attach(os.path.basename(invoice_path), "application/pdf", fp.read())
            mail.send(msg)
        except Exception as e:
            print(f"Erreur lors de l'envoi de l'email: {e}")

    session.pop('cart', None)

    return render_template('success.html', invoice_path=invoice_path)

# Auction routes
@app.route('/live_auctions')
def live_auctions():
    auctions = Auction.query.filter_by(is_active=True).all()
    return render_template('live_auctions.html', auctions=auctions)

@app.route('/auction/<int:auction_id>')
def auction_detail(auction_id):
    auction = Auction.query.get_or_404(auction_id)
    if auction.is_active:
        return render_template('auction_detail.html', auction=auction)
    else:
        return "Cette enchère a déjà été terminée.", 404

@app.route('/place_bid/<int:auction_id>', methods=['POST'])
def place_bid(auction_id):
    if 'customer_email' not in session:
        return redirect(url_for('login'))
    data = request.json
    amount = data.get('amount')
    email = session.get('customer_email')
    bid = Bid(user_email=email, auction_id=auction_id, amount=amount)
    db.session.add(bid)
    db.session.commit()
    pusher_client.trigger(f"auction-{auction_id}", "new-bid", {'email': email, 'amount': amount})
    return jsonify({'success': True})

# History
@app.route('/history')
def history():
    if 'customer_email' not in session:
        return redirect(url_for('login'))
    email = session['customer_email']
    bids = Bid.query.filter_by(user_email=email).all()
    return render_template('history.html', bids=bids)

# Admin routes
@app.route('/admin')
def admin():
    user_email = session.get('customer_email')
    if not user_email:
        return redirect(url_for('login'))
    
    user = User.query.filter_by(email=user_email).first()
    if not user or not user.is_admin:
        return redirect(url_for('login'))
    
    # Get all required data for admin panel
    products = Product.query.all()
    active_auctions = Auction.query.filter(Auction.end_time > datetime.utcnow()).all()
    ended_auctions = Auction.query.filter(Auction.end_time <= datetime.utcnow()).all()
    users = User.query.all()
    
    # Process ended auctions with highest bids
    ended_auctions_result = []
    for auction in ended_auctions:
        highest_bid = Bid.query.filter_by(auction_id=auction.id).order_by(Bid.amount.desc()).first()
        ended_auctions_result.append((auction, highest_bid))
    
    return render_template('admin.html', 
                         products=products,
                         active_auctions=active_auctions,
                         ended_auctions=ended_auctions_result,
                         users=users)


@app.route('/products', methods=['GET'])
def get_all_products():
    try:
        products = Product.query.all()
        product_list = []

        for product in products:
            product_list.append({
                'id': product.id,
                'name': product.name,
                'brand': product.brand,
                'bag_style': product.bag_style,
                'skin_type': product.skin_type,
                'inner_material': product.inner_material,
                'major_color': product.major_color,
                'volume': product.volume,
                'accessories': product.accessories,
                'price': product.price,
                'stock': product.stock,
                'is_auction': product.is_auction,
                'image': url_for('static', filename='images/' + product.image)  # adapte si besoin
            })

        return jsonify({'products': product_list})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/admin/add_product', methods=['POST'])
def admin_add_product():
    if 'customer_email' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user = User.query.filter_by(email=session['customer_email']).first()
    if not user or not user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403

    try:
        # Récupération des données du formulaire
        name = request.form.get('name')
        brand = request.form.get('brand')
        bag_style = request.form.get('bag_style')
        skin_type = request.form.get('skin_type')
        inner_material = request.form.get('inner_material')
        major_color = request.form.get('major_color')
        volume = float(request.form.get('volume'))
        accessories = request.form.get('accessories')
        price = float(request.form.get('price'))
        stock = int(request.form.get('stock'))
        is_auction = 'is_auction' in request.form

        # Vérification et enregistrement de l'image
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400

        image = request.files['image']
        if image.filename == '':
            return jsonify({'error': 'No image selected'}), 400

        if image and allowed_file(image.filename):
            filename = secure_filename(image.filename)
            if not os.path.exists(app.config['UPLOAD_FOLDER']):
                os.makedirs(app.config['UPLOAD_FOLDER'])
            image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            image.save(image_path)

            # Création de l'objet produit
            product = Product(
                name=name,
                brand=brand,
                bag_style=bag_style,
                skin_type=skin_type,
                inner_material=inner_material,
                major_color=major_color,
                volume=volume,
                accessories=accessories,
                price=price,
                stock=stock,
                image=filename,
                is_auction=is_auction
            )
            db.session.add(product)
            db.session.commit()

            return jsonify({'success': True, 'message': 'Produit ajouté avec succès'})
        else:
            return jsonify({'error': 'Type de fichier invalide'}), 400

    except Exception as e:
        return jsonify({'error': str(e)}), 500


# Add these routes to your existing app.py

@app.route('/admin/delete_product/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    if 'customer_email' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.filter_by(email=session['customer_email']).first()
    if not user or not user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        product = Product.query.get_or_404(product_id)
        
        # Delete associated auctions first
        Auction.query.filter_by(product_id=product_id).delete()
        
        # Delete the product
        db.session.delete(product)
        db.session.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/admin/update_product/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    if 'customer_email' not in session:
        return jsonify({'error': 'Unauthorized'}), 401

    user = User.query.filter_by(email=session['customer_email']).first()
    if not user or not user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403

    try:
        product = Product.query.get_or_404(product_id)
        data = request.get_json()

        # Mettre à jour tous les champs du formulaire
        product.name = data.get('name', product.name)
        product.price = float(data.get('price', product.price))
        product.stock = int(data.get('stock', product.stock))
        product.major_color = data.get('major_color', product.major_color)
        product.volume = int(data.get('volume', product.volume))
        product.skin_type = data.get('skin_type', product.skin_type)
        product.inner_material = data.get('inner_material', product.inner_material)
        product.accessories = data.get('accessories', product.accessories)
        product.bag_style = data.get('bag_style', product.bag_style)

        # Checkbox : true/false
        product.is_auction = bool(data.get('is_auction', False))

        db.session.commit()
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/admin/get_auction_products')
def get_auction_products():
    if 'customer_email' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.filter_by(email=session['customer_email']).first()
    if not user or not user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    auction_products = Product.query.filter_by(is_auction=True).all()
    products_data = [{
        'id': p.id,
        'name': p.name
    } for p in auction_products]
    
    return jsonify(products_data)

@app.route('/admin/add_auction', methods=['POST'])
def add_auction():
    if 'customer_email' not in session:
        return jsonify({'error': 'Unauthorized'}), 401
    
    user = User.query.filter_by(email=session['customer_email']).first()
    if not user or not user.is_admin:
        return jsonify({'error': 'Unauthorized'}), 403
    
    try:
        product_id = request.form.get('product_id')
        start_time = datetime.strptime(request.form.get('start_time'), '%Y-%m-%dT%H:%M')
        end_time = datetime.strptime(request.form.get('end_time'), '%Y-%m-%dT%H:%M')
        
        # Check if product exists and is marked for auction
        product = Product.query.get(product_id)
        if not product or not product.is_auction:
            return jsonify({'error': 'Invalid product for auction'}), 400
        
        auction = Auction(
            product_id=product_id,
            start_time=start_time,
            end_time=end_time,
            is_active=True
        )
        db.session.add(auction)
        db.session.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    # Créer un DataFrame avec les bons noms de colonnes
    features_df = pd.DataFrame([{
        'brand': data['brand'],
        'bag style': data['bag_style'],
        'skin type': data['skin_type'],
        'inner material': data['inner_material'],
        'major color': data['major_color'],
        'volume': data['volume'],
        'accessories': data['accessories']
    }])

    # Prédiction
    predicted_price = model.predict(features_df)

    return jsonify(predicted_price=predicted_price[0])



if __name__ == '__main__':
    CORS(app)
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)