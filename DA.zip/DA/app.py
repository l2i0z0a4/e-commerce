from flask import Flask, render_template, request, jsonify , Response
import requests

app = Flask(__name__)


API_KEY = "2005aa21ef57419ea395f4e5cde7dfb7"
BASE_URL = "https://openexchangerates.org/api/latest.json?app_id=" + API_KEY

# Liste des devises prises en charge
devises = {"DZD": "Dinar Algérien", "EUR": "Euro", "USD": "Dollar Américain"}


def get_exchange_rates():
    response = requests.get(BASE_URL)
    if response.status_code == 200:
        return response.json().get("rates", {})
    return {}


@app.route("/wadl")
def get_wadl():
    wadl_content = """<?xml version="1.0" encoding="UTF-8"?>
    <application xmlns="http://wadl.dev.java.net/2009/02">
        <doc title="API de conversion de devises">
            <doc>Cette API permet de convertir une devise en une autre.</doc>
        </doc>
        <resources base="http://localhost:5000/">
            <resource path="convert">
                <method name="POST">
                    <doc>Convertir une devise en une autre</doc>
                    <request>
                        <param name="amount" type="xs:float" style="query" required="true">
                            <doc>Montant à convertir</doc>
                        </param>
                        <param name="from_currency" type="xs:string" style="query" required="true">
                            <doc>Devise source (ex: USD, EUR, DZD)</doc>
                        </param>
                        <param name="to_currency" type="xs:string" style="query" required="true">
                            <doc>Devise cible (ex: USD, EUR, DZD)</doc>
                        </param>
                    </request>
                    <response status="200">
                        <doc>Conversion réussie</doc>
                        <representation mediaType="application/json"/>
                    </response>
                    <response status="400">
                        <doc>Requête invalide - données incorrectes ou incomplètes</doc>
                    </response>
                </method>
            </resource>
        </resources>
    </application>"""

    return Response(wadl_content, mimetype="application/xml")


@app.route("/")
def index():
    return render_template("index.html", devises=devises)


@app.route("/convert", methods=["POST"])
def convert():
    try:
        amount = float(request.form["amount"])
        from_currency = request.form["from_currency"]
        to_currency = request.form["to_currency"]

        rates = get_exchange_rates()
        if from_currency == "DZD":
            converted_amount = amount / rates["DZD"] * rates[to_currency]
        elif to_currency == "DZD":
            converted_amount = amount / rates[from_currency] * rates["DZD"]
        else:
            converted_amount = amount / rates[from_currency] * rates[to_currency]

        return jsonify({"result": round(converted_amount, 2)})
    except Exception as e:
        return jsonify({"error": str(e)})


if __name__ == "__main__":
    app.run(debug=True)
